package com.ngoconnect.fooddonation.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.ngoconnect.fooddonation.data.FirebaseRepository
import com.ngoconnect.fooddonation.databinding.ActivityLoginBinding
import com.ngoconnect.fooddonation.donor.DonorHomeActivity
import com.ngoconnect.fooddonation.model.Role
import com.ngoconnect.fooddonation.ngo.NgoDashboardActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val repository = FirebaseRepository()
    private val auth by lazy {
        try {
            FirebaseAuth.getInstance()
        } catch (_: Exception) {
            null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Check if Firebase is initialized
        if (auth == null) {
            Toast.makeText(this, "Demo Mode: Firebase not configured.", Toast.LENGTH_SHORT).show()
        }

        // Check if user is already signed in
        auth?.currentUser?.uid?.let { userId ->
            checkUserRoleAndNavigate(userId)
        }

        binding.loginButton.setOnClickListener {
            val email = binding.emailInput.text.toString().trim()
            val password = binding.passwordInput.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val currentAuth = auth
            if (currentAuth == null) {
                // Demo bypass for when Firebase is not configured
                when {
                    (email == "demo@example.com") && (password == "password") -> {
                        startActivity(Intent(this, DonorHomeActivity::class.java))
                        finish()
                    }
                    (email == "ngo@example.com") && (password == "password") -> {
                        startActivity(Intent(this, NgoDashboardActivity::class.java))
                        finish()
                    }
                    (email == "both@example.com") && (password == "password") -> {
                        startActivity(Intent(this, DonorHomeActivity::class.java))
                        finish()
                    }
                    else -> {
                        Toast.makeText(this, "Demo: Use demo@example.com, ngo@example.com, or both@example.com", Toast.LENGTH_LONG).show()
                    }
                }
                return@setOnClickListener
            }

            currentAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        task.result?.user?.uid?.let { checkUserRoleAndNavigate(it) }
                    } else {
                        Toast.makeText(this, "Login failed: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                    }
                }
        }

        binding.signUpPrompt.setOnClickListener {
            val email = binding.emailInput.text.toString().trim()
            val password = binding.passwordInput.text.toString().trim()

            val currentAuth = auth
            if (currentAuth == null) {
                startActivity(Intent(this, RoleSelectionActivity::class.java))
                finish()
            } else {
                if (email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(this, "Fill email/password to create a real account, or just proceed to demo.", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, RoleSelectionActivity::class.java))
                    finish()
                } else {
                    currentAuth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                startActivity(Intent(this, RoleSelectionActivity::class.java))
                                finish()
                            } else {
                                Toast.makeText(this, "Sign up failed: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                }
            }
        }
    }

    private fun checkUserRoleAndNavigate(userId: String) {
        repository.getUser(userId) { user ->
            if (user != null) {
                val intent = if (user.role == Role.NGO) {
                    Intent(this, NgoDashboardActivity::class.java)
                } else {
                    Intent(this, DonorHomeActivity::class.java)
                }
                startActivity(intent)
                finish()
            } else {
                startActivity(Intent(this, RoleSelectionActivity::class.java))
                finish()
            }
        }
    }
}