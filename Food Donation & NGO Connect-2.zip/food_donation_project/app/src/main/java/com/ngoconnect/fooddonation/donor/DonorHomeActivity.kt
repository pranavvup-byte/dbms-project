package com.ngoconnect.fooddonation.donor

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.ListenerRegistration
import com.ngoconnect.fooddonation.R
import com.ngoconnect.fooddonation.auth.LoginActivity
import com.ngoconnect.fooddonation.data.FirebaseRepository
import com.ngoconnect.fooddonation.databinding.ActivityDonorHomeBinding
import com.ngoconnect.fooddonation.impact.ImpactDashboardActivity
import com.ngoconnect.fooddonation.model.Role
import com.ngoconnect.fooddonation.ngo.NgoDashboardActivity
import com.ngoconnect.fooddonation.status.DonationStatusActivity

/**
 * Screen 2: Donor Home - welcome, active donations list, + Donate Food action.
 */
class DonorHomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDonorHomeBinding
    private lateinit var adapter: DonationAdapter
    private val repository = FirebaseRepository()
    private var donationsListener: ListenerRegistration? = null

    private val donorId: String
        get() = try {
            FirebaseAuth.getInstance().currentUser?.uid ?: DEMO_DONOR_ID
        } catch (_: Exception) {
            DEMO_DONOR_ID
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDonorHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository.getUser(donorId) { user ->
            if (user != null) {
                binding.donorName.text = user.name
                if (user.role == Role.BOTH) {
                    binding.switchRoleButton.visibility = View.VISIBLE
                    binding.switchRoleButton.setOnClickListener {
                        startActivity(Intent(this, NgoDashboardActivity::class.java))
                        finish()
                    }
                }
            } else {
                binding.donorName.text = getString(R.string.demo_donor_name)
            }
        }

        adapter = DonationAdapter(emptyList()) { donation ->
            startActivity(
                Intent(this, DonationStatusActivity::class.java)
                    .putExtra(DonationStatusActivity.EXTRA_DONATION_ID, donation.donationId),
            )
        }
        binding.donationsRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.donationsRecyclerView.adapter = adapter

        binding.logoutButton.setOnClickListener {
            try {
                FirebaseAuth.getInstance().signOut()
            } catch (_: Exception) {
                // Ignore for demo
            }
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        binding.donateFoodFab.setOnClickListener {
            startActivity(Intent(this, CreateDonationActivity::class.java))
        }
        binding.viewImpactLink.setOnClickListener {
            startActivity(Intent(this, ImpactDashboardActivity::class.java))
        }
    }

    override fun onStart() {
        super.onStart()
        donationsListener = repository.listenToDonorDonations(donorId) { donations ->
            adapter.submitList(donations)
            binding.emptyState.visibility = if (donations.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    override fun onStop() {
        super.onStop()
        donationsListener?.remove()
        donationsListener = null
    }

    companion object {
        private const val DEMO_DONOR_ID = "demo-donor"
    }
}