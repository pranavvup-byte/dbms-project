# Fix All Warnings and Errors in Project

This plan addresses all identified IDE warnings and build-related suggestions to clean up the codebase, improve maintainability, and ensure the project follows Android best practices.

## User Review Required

> [!NOTE]
> Several warnings refer to "unused" functions or classes. In many cases, these appear to be infrastructure meant for future use (e.g., `FirebaseRepository` methods). I will leave them as they are if they seem intended for future implementation, or I can add `@Suppress("UNUSED_PARAMETER", "unused")` to suppress the warnings without removing the code.

> [!IMPORTANT]
> Dependency version updates in `build.gradle.kts` might cause breaking changes if the new versions have different APIs. I will proceed with updates but verify the build.

## Proposed Changes

### Build Configuration

#### [MODIFY] [build.gradle.kts](file:///C:/Users/Ananya/Downloads/food_donation_project/app/build.gradle.kts)
- Update `compileSdk` and `targetSdk` to 34 (or 35 if available and safe).
- Update dependencies to their latest stable versions as suggested by the IDE analysis:
    - `androidx.core:core-ktx:1.13.1` -> `1.15.0`
    - `androidx.appcompat:appcompat:1.7.0` -> `1.7.0` (Latest stable is 1.7.0, analysis suggested 1.8.0 but that might be preview)
    - `com.google.android.material:material:1.12.0` -> `1.12.0` (Checking latest stable)
    - `androidx.constraintlayout:constraintlayout:2.1.4` -> `2.2.0`
    - `androidx.lifecycle:lifecycle-livedata-ktx:2.8.4` -> `2.8.7`
    - `com.google.firebase:firebase-bom:33.1.2` -> `33.9.0`

### Data Layer

#### [MODIFY] [FirebaseRepository.kt](file:///C:/Users/Ananya/Downloads/food_donation_project/app/src/main/java/com/ngoconnect/fooddonation/data/FirebaseRepository.kt)
- Add clarifying parentheses in logical expressions.
- Add missing trailing commas.
- Suppress "unused" warnings for methods that are likely part of the API.

#### [MODIFY] [FakeRepository.kt](file:///C:/Users/Ananya/Downloads/food_donation_project/app/src/main/java/com/ngoconnect/fooddonation/data/FakeRepository.kt)
- Suppress "unused" warnings.

### Donor Feature

#### [MODIFY] [DonorHomeActivity.kt](file:///C:/Users/Ananya/Downloads/food_donation_project/app/src/main/java/com/ngoconnect/fooddonation/donor/DonorHomeActivity.kt)
- Move hardcoded strings to `strings.xml`.
- Add missing trailing commas.

#### [MODIFY] [DonationAdapter.kt](file:///C:/Users/Ananya/Downloads/food_donation_project/app/src/main/java/com/ngoconnect/fooddonation/donor/DonationAdapter.kt)
- Remove redundant `inner` modifier on `ViewHolder`.
- Use resource strings with placeholders for pickups info instead of string concatenation.
- Add missing trailing commas.

### Geo and Location

#### [MODIFY] [GeoMatchingRepository.kt](file:///C:/Users/Ananya/Downloads/food_donation_project/app/src/main/java/com/ngoconnect/fooddonation/geo/GeoMatchingRepository.kt)
- Suppress "unused" warnings.

#### [MODIFY] [LocationHelper.kt](file:///C:/Users/Ananya/Downloads/food_donation_project/app/src/main/java/com/ngoconnect/fooddonation/geo/LocationHelper.kt)
- Add missing trailing commas.
- Suppress "unused" warnings.

### UI Resources

#### [MODIFY] [activity_donor_home.xml](file:///C:/Users/Ananya/Downloads/food_donation_project/app/src/main/res/layout/activity_donor_home.xml)
- Remove unused `xmlns:app` namespace.

#### [MODIFY] [strings.xml](file:///C:/Users/Ananya/Downloads/food_donation_project/app/src/main/res/values/strings.xml)
- Add new string resources for hardcoded text.

### Activities and Status

#### [MODIFY] [DonationStatusActivity.kt](file:///C:/Users/Ananya/Downloads/food_donation_project/app/src/main/java/com/ngoconnect/fooddonation/status/DonationStatusActivity.kt)
- Fix unused `donationId` variable warning.

## Verification Plan

### Automated Tests
- Run `gradlew assembleDebug` to ensure the project still builds after dependency updates.
- Run `analyze_file` on modified files to verify warnings are gone.

### Manual Verification
- Verify that the app still launches and basic navigation (like Donor Home) works.
