package com.ngoconnect.fooddonation.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.ngoconnect.fooddonation.R
import com.ngoconnect.fooddonation.data.FirebaseRepository
import com.ngoconnect.fooddonation.databinding.ActivityRoleselectionBinding
import com.ngoconnect.fooddonation.donor.DonorHomeActivity
import com.ngoconnect.fooddonation.model.Role
import com.ngoconnect.fooddonation.model.User
import com.ngoconnect.fooddonation.ngo.NgoDashboardActivity

class RoleSelectionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRoleselectionBinding
    private val repository = FirebaseRepository()
    private val auth by lazy {
        try {
            FirebaseAuth.getInstance()
        } catch (_: Exception) {
            null
        }
    }
    private var selectedRole: Role? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRoleselectionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.donorCard.setOnClickListener {
            selectedRole = Role.DONOR
            updateSelectionVisuals()
        }

        binding.ngoCard.setOnClickListener {
            selectedRole = Role.NGO
            updateSelectionVisuals()
        }

        binding.bothCard.setOnClickListener {
            selectedRole = Role.BOTH
            updateSelectionVisuals()
        }

        binding.continueButton.setOnClickListener {
            saveProfileAndNavigate()
        }
    }

    private fun saveProfileAndNavigate() {
        val name = binding.nameInput.text.toString().trim()
        val role = selectedRole
        val userId = auth?.currentUser?.uid ?: "demo-user-${System.currentTimeMillis()}"

        if (name.isEmpty()) {
            Toast.makeText(this, "Please enter your name", Toast.LENGTH_SHORT).show()
            return
        }

        if (role == null) {
            Toast.makeText(this, "Please select a role", Toast.LENGTH_SHORT).show()
            return
        }

        val user = User(
            userId = userId,
            name = name,
            role = role,
        )

        Toast.makeText(this, "Setting up your profile...", Toast.LENGTH_SHORT).show()

        try {
            repository.saveUser(user) { _ ->
                navigateToHome()
            }
        } catch (_: Exception) {
            navigateToHome()
        }
    }

    private fun updateSelectionVisuals() {
        val activeStrokeColor = getColor(R.color.primary)
        val inactiveStrokeColor = getColor(R.color.card_stroke)
        val activeBgColor = getColor(R.color.primary_light)
        val inactiveBgColor = getColor(R.color.surface)

        val isDonor = selectedRole == Role.DONOR
        binding.donorCard.strokeColor = if (isDonor) activeStrokeColor else inactiveStrokeColor
        binding.donorCard.strokeWidth = if (isDonor) 6 else 2
        binding.donorCard.setCardBackgroundColor(if (isDonor) activeBgColor else inactiveBgColor)
        binding.donorCard.elevation = if (isDonor) 8f else 2f

        val isNgo = selectedRole == Role.NGO
        binding.ngoCard.strokeColor = if (isNgo) activeStrokeColor else inactiveStrokeColor
        binding.ngoCard.strokeWidth = if (isNgo) 6 else 2
        binding.ngoCard.setCardBackgroundColor(if (isNgo) activeBgColor else inactiveBgColor)
        binding.ngoCard.elevation = if (isNgo) 8f else 2f

        val isBoth = selectedRole == Role.BOTH
        binding.bothCard.strokeColor = if (isBoth) activeStrokeColor else inactiveStrokeColor
        binding.bothCard.strokeWidth = if (isBoth) 6 else 2
        binding.bothCard.setCardBackgroundColor(if (isBoth) activeBgColor else inactiveBgColor)
        binding.bothCard.elevation = if (isBoth) 8f else 2f
    }

    private fun navigateToHome() {
        val intent = when (selectedRole) {
            Role.NGO -> Intent(this, NgoDashboardActivity::class.java)
            Role.BOTH -> Intent(this, DonorHomeActivity::class.java)
            else -> Intent(this, DonorHomeActivity::class.java)
        }
        startActivity(intent)
        finish()
    }
}