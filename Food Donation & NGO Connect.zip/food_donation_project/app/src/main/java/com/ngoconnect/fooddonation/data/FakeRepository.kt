package com.ngoconnect.fooddonation.data

import com.ngoconnect.fooddonation.model.Donation

/**
 * STUB — this class was referenced by DonorHomeActivity.kt but not included
 * in the uploaded project files. Replace with a real Firestore-backed
 * repository (see the TODO in DonorHomeActivity.refreshDonations).
 */
@Suppress("unused")
object FakeRepository {
    fun allForDonor(): List<Donation> = emptyList()
}
