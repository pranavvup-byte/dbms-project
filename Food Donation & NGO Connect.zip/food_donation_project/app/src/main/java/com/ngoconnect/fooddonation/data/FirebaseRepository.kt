package com.ngoconnect.fooddonation.data

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.ngoconnect.fooddonation.model.Donation
import com.ngoconnect.fooddonation.model.DonationStatus
import com.ngoconnect.fooddonation.model.Ngo
import com.ngoconnect.fooddonation.model.User

/**
 * Data Management Module (Module 6).
 */
@Suppress("unused")
class FirebaseRepository {

    private val db by lazy {
        try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            null
        }
    }
    private val usersRef by lazy { db?.collection(COLLECTION_USERS) }
    private val ngosRef by lazy { db?.collection(COLLECTION_NGOS) }
    private val donationsRef by lazy { db?.collection(COLLECTION_DONATIONS) }

    // --- Demo Cache (In-Memory) ---
    companion object {
        const val COLLECTION_USERS = "users"
        const val COLLECTION_NGOS = "ngos"
        const val COLLECTION_DONATIONS = "donations"
        
        private val demoUsers = mutableMapOf<String, User>()
        private val demoDonations = mutableMapOf<String, Donation>()
    }

    // ---------- Users ----------

    fun saveUser(user: User, onComplete: (Boolean) -> Unit) {
        demoUsers[user.userId] = user // Always save to demo cache
        
        val ref = usersRef
        if (ref == null) {
            onComplete(true) // Proceed in demo mode
            return
        }
        ref.document(user.userId).set(user)
            .addOnSuccessListener { onComplete(true) }
            .addOnFailureListener { onComplete(true) } // Still true for demo
    }

    fun getUser(userId: String, onResult: (User?) -> Unit) {
        if (demoUsers.containsKey(userId)) {
            onResult(demoUsers[userId])
            return
        }

        val ref = usersRef
        if (ref == null) {
            onResult(null)
            return
        }
        ref.document(userId).get()
            .addOnSuccessListener { doc -> onResult(doc.toObject(User::class.java)) }
            .addOnFailureListener { onResult(null) }
    }

    // ---------- NGOs ----------

    fun saveNgo(ngo: Ngo, onComplete: (Boolean) -> Unit) {
        val ref = ngosRef
        if (ref == null) {
            onComplete(true)
            return
        }
        ref.document(ngo.ngoId).set(ngo)
            .addOnSuccessListener { onComplete(true) }
            .addOnFailureListener { onComplete(true) }
    }

    fun getVerifiedNgos(onResult: (List<Ngo>) -> Unit) {
        val ref = ngosRef
        if (ref == null) {
            onResult(emptyList())
            return
        }
        ref.whereEqualTo("verified", true).get()
            .addOnSuccessListener { snapshot ->
                onResult(snapshot.documents.mapNotNull { it.toObject(Ngo::class.java) })
            }
            .addOnFailureListener { onResult(emptyList()) }
    }

    // ---------- Donations ----------

    fun createDonation(donation: Donation, onComplete: (String?) -> Unit) {
        val ref = donationsRef
        val id = donation.donationId.ifBlank { "demo-${System.currentTimeMillis()}" }
        val finalDonation = donation.copy(donationId = id)
        
        demoDonations[id] = finalDonation // Save to demo cache
        
        if (ref == null) {
            onComplete(id)
            return
        }
        val docRef = ref.document(id)
        docRef.set(finalDonation)
            .addOnSuccessListener { onComplete(id) }
            .addOnFailureListener { onComplete(id) }
    }

    fun getDonation(donationId: String, onResult: (Donation?) -> Unit) {
        if (demoDonations.containsKey(donationId)) {
            onResult(demoDonations[donationId])
            return
        }

        val ref = donationsRef
        if (ref == null) {
            onResult(null)
            return
        }
        ref.document(donationId).get()
            .addOnSuccessListener { onResult(it.toObject(Donation::class.java)) }
            .addOnFailureListener { onResult(null) }
    }

    fun updateDonationMatch(donationId: String, ngo: Ngo, distanceKm: Double, onComplete: (Boolean) -> Unit) {
        demoDonations[donationId]?.let {
            demoDonations[donationId] = it.copy(
                ngoId = ngo.ngoId,
                ngoName = ngo.name,
                distanceKm = distanceKm,
                status = DonationStatus.NGO_FOUND
            )
        }

        val ref = donationsRef
        if (ref == null) {
            onComplete(true)
            return
        }
        ref.document(donationId)
            .update(
                mapOf(
                    "ngoId" to ngo.ngoId,
                    "ngoName" to ngo.name,
                    "distanceKm" to distanceKm,
                    "status" to DonationStatus.NGO_FOUND.name,
                ),
            )
            .addOnSuccessListener { onComplete(true) }
            .addOnFailureListener { onComplete(true) }
    }

    fun updateDonationStatus(donationId: String, status: DonationStatus, onComplete: (Boolean) -> Unit) {
        demoDonations[donationId]?.let {
            demoDonations[donationId] = it.copy(status = status)
        }

        val ref = donationsRef
        if (ref == null) {
            onComplete(true)
            return
        }
        ref.document(donationId).update("status", status.name)
            .addOnSuccessListener { onComplete(true) }
            .addOnFailureListener { onComplete(true) }
    }

    fun donationsForDonor(donorId: String, onResult: (List<Donation>) -> Unit) {
        val filteredDemo = demoDonations.values.filter { it.donorId == donorId }
        
        val ref = donationsRef
        if (ref == null) {
            onResult(filteredDemo)
            return
        }
        ref.whereEqualTo("donorId", donorId)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .get()
            .addOnSuccessListener { snapshot -> 
                val firestoreList = snapshot.documents.mapNotNull { it.toObject(Donation::class.java) }
                onResult(if (firestoreList.isNotEmpty()) firestoreList else filteredDemo)
            }
            .addOnFailureListener { onResult(filteredDemo) }
    }

    fun listenToDonorDonations(donorId: String, onChange: (List<Donation>) -> Unit): ListenerRegistration? {
        val ref = donationsRef
        if (ref == null) {
            onChange(demoDonations.values.filter { it.donorId == donorId }.sortedByDescending { it.createdAt })
            return null
        }
        return ref.whereEqualTo("donorId", donorId)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if ((error != null) || (snapshot == null)) {
                    onChange(demoDonations.values.filter { it.donorId == donorId }.sortedByDescending { it.createdAt })
                } else {
                    onChange(snapshot.documents.mapNotNull { it.toObject(Donation::class.java) })
                }
            }
    }

    fun listenToListedDonations(onChange: (List<Donation>) -> Unit): ListenerRegistration? {
        val ref = donationsRef
        if (ref == null) {
            onChange(demoDonations.values.filter { it.status == DonationStatus.LISTED }.sortedByDescending { it.createdAt })
            return null
        }
        return ref.whereEqualTo("status", DonationStatus.LISTED.name)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if ((error != null) || (snapshot == null)) {
                    onChange(demoDonations.values.filter { it.status == DonationStatus.LISTED }.sortedByDescending { it.createdAt })
                } else {
                    onChange(snapshot.documents.mapNotNull { it.toObject(Donation::class.java) })
                }
            }
    }
}
