package com.ngoconnect.fooddonation.donor

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.ngoconnect.fooddonation.data.FirebaseRepository
import com.ngoconnect.fooddonation.databinding.ActivityCreateDonationBinding
import com.ngoconnect.fooddonation.model.Donation
import com.ngoconnect.fooddonation.model.DonationStatus
import java.util.*

class CreateDonationActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreateDonationBinding
    private val repository = FirebaseRepository()
    private val calendar = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateDonationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupPickers()

        binding.submitDonationButton.setOnClickListener {
            submitDonation()
        }
    }

    private fun setupPickers() {
        binding.pickupDateInput.setOnClickListener {
            DatePickerDialog(
                this,
                { _, year, month, day ->
                    val dateStr = String.format(Locale.getDefault(), "%02d/%02d/%d", day, month + 1, year)
                    binding.pickupDateInput.setText(dateStr)
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        binding.pickupTimeInput.setOnClickListener {
            TimePickerDialog(
                this,
                { _, hour, minute ->
                    val timeStr = String.format(Locale.getDefault(), "%02d:%02d", hour, minute)
                    binding.pickupTimeInput.setText(timeStr)
                },
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                true
            ).show()
        }
    }

    private fun submitDonation() {
        val foodType = binding.foodTypeInput.text.toString().trim()
        val quantity = binding.quantityInput.text.toString().trim()
        val date = binding.pickupDateInput.text.toString().trim()
        val time = binding.pickupTimeInput.text.toString().trim()
        val location = binding.pickupLocationInput.text.toString().trim()

        if (foodType.isEmpty() || quantity.isEmpty() || date.isEmpty() || time.isEmpty() || location.isEmpty()) {
            Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show()
            return
        }

        val donorId = try {
            FirebaseAuth.getInstance().currentUser?.uid
        } catch (e: Exception) {
            null
        } ?: "demo-donor"

        val donation = Donation(
            donorId = donorId,
            foodType = foodType,
            quantity = quantity,
            pickupDate = date,
            pickupTime = time,
            pickupLocation = location,
            description = binding.descriptionInput.text.toString().trim(),
            status = DonationStatus.LISTED,
            createdAt = System.currentTimeMillis()
        )

        repository.createDonation(donation) { _ ->
            showSuccessSummary(donation)
        }
    }

    private fun showSuccessSummary(donation: Donation) {
        val message = """
            Your donation has been listed!
            
            Food: ${donation.foodType}
            Quantity: ${donation.quantity}
            Pickup: ${donation.pickupDate} at ${donation.pickupTime}
            Location: ${donation.pickupLocation}
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("Donation Submitted")
            .setMessage(message)
            .setPositiveButton("OK") { _, _ ->
                finish()
            }
            .setCancelable(false)
            .show()
    }
}
