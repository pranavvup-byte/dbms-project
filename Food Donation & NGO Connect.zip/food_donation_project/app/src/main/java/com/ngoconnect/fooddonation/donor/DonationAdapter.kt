package com.ngoconnect.fooddonation.donor

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ngoconnect.fooddonation.R
import com.ngoconnect.fooddonation.databinding.ItemDonationBinding
import com.ngoconnect.fooddonation.model.Donation
import com.ngoconnect.fooddonation.model.DonationStatus

class DonationAdapter(
    private var items: List<Donation>,
    private val onClick: (Donation) -> Unit,
) : RecyclerView.Adapter<DonationAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemDonationBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemDonationBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val donation = items[position]
        with(holder.binding) {
            val context = root.context
            foodType.text = donation.foodType
            quantity.text = donation.quantity
            pickupInfo.text = context.getString(
                R.string.pickup_info_format,
                donation.pickupDate,
                donation.pickupTime,
                donation.pickupLocation,
            )
            statusPill.text = donation.status.label.uppercase()
            statusPill.setBackgroundResource(statusPillBackground(donation.status))
            statusPill.setTextColor(statusPillTextColor(context, donation.status))

            distanceOrNgo.text = donation.ngoName?.let {
                context.getString(R.string.matched_with, it)
            } ?: context.getString(R.string.waiting_for_ngo)

            root.setOnClickListener { onClick(donation) }
        }
    }

    override fun getItemCount(): Int = items.size

    fun submitList(newItems: List<Donation>) {
        items = newItems
        notifyDataSetChanged()
    }

    companion object {
        fun statusPillBackground(status: DonationStatus): Int {
            return when (status) {
                DonationStatus.LISTED -> R.drawable.bg_pill_listed
                DonationStatus.NGO_FOUND -> R.drawable.bg_pill_matched
                DonationStatus.PICKUP_SCHEDULED -> R.drawable.bg_pill_scheduled
                DonationStatus.COMPLETED -> R.drawable.bg_pill_completed
            }
        }

        fun statusPillTextColor(context: Context, status: DonationStatus): Int {
            return when (status) {
                DonationStatus.LISTED -> context.getColor(R.color.status_listed)
                DonationStatus.NGO_FOUND -> context.getColor(R.color.status_matched)
                DonationStatus.PICKUP_SCHEDULED -> context.getColor(R.color.status_scheduled)
                DonationStatus.COMPLETED -> context.getColor(R.color.status_completed)
            }
        }
    }
}