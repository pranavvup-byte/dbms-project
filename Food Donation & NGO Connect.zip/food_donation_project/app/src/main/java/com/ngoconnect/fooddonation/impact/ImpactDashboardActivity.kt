package com.ngoconnect.fooddonation.impact

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.ngoconnect.fooddonation.data.FirebaseRepository
import com.ngoconnect.fooddonation.databinding.ActivityImpactDashboardBinding
import com.ngoconnect.fooddonation.model.DonationStatus

class ImpactDashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityImpactDashboardBinding
    private val repository = FirebaseRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityImpactDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val userId = try {
            FirebaseAuth.getInstance().currentUser?.uid
        } catch (e: Exception) {
            null
        } ?: "demo-donor"

        repository.donationsForDonor(userId) { donations ->
            val completed = donations.filter { it.status == DonationStatus.COMPLETED }
            
            // Calculate Food Saved (simplified parsing of quantity)
            val totalKg = completed.sumOf { donation ->
                val quantityStr = donation.quantity.lowercase()
                when {
                    quantityStr.contains("kg") -> quantityStr.replace("kg", "").trim().toDoubleOrNull() ?: 0.0
                    quantityStr.contains("servings") -> (quantityStr.replace("servings", "").trim().toDoubleOrNull() ?: 0.0) * 0.5
                    else -> 1.0 // Default 1kg per item if unknown
                }
            }
            
            binding.foodSavedValue.text = "${String.format("%.1f", totalKg)} kg"
            binding.pickupsValue.text = completed.size.toString()
            binding.ngosServedValue.text = completed.mapNotNull { it.ngoId }.distinct().size.toString()
        }
    }
}
