package com.ngoconnect.fooddonation.ngo

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.auth.FirebaseAuth
import com.ngoconnect.fooddonation.auth.LoginActivity
import com.ngoconnect.fooddonation.data.FirebaseRepository
import com.ngoconnect.fooddonation.databinding.ActivityNgoDashboardBinding
import com.ngoconnect.fooddonation.donor.DonationAdapter
import com.ngoconnect.fooddonation.donor.DonorHomeActivity
import com.ngoconnect.fooddonation.model.Role
import com.ngoconnect.fooddonation.status.DonationStatusActivity

class NgoDashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNgoDashboardBinding
    private val repository = FirebaseRepository()
    private lateinit var adapter: DonationAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNgoDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val userId = try {
            FirebaseAuth.getInstance().currentUser?.uid
        } catch (e: Exception) {
            null
        } ?: "demo-ngo"

        repository.getUser(userId) { user ->
            binding.ngoName.text = user?.name ?: "Helping Hands NGO"
            if (user?.role == Role.BOTH) {
                binding.switchRoleButton.visibility = View.VISIBLE
                binding.switchRoleButton.setOnClickListener {
                    startActivity(Intent(this, DonorHomeActivity::class.java))
                    finish()
                }
            }
        }

        adapter = DonationAdapter(emptyList()) { donation ->
            startActivity(
                Intent(this, DonationStatusActivity::class.java)
                    .putExtra(DonationStatusActivity.EXTRA_DONATION_ID, donation.donationId)
            )
        }

        binding.nearbyDonationsRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.nearbyDonationsRecyclerView.adapter = adapter

        binding.logoutButton.setOnClickListener {
            try {
                FirebaseAuth.getInstance().signOut()
            } catch (e: Exception) {}
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        refreshDonations()
    }

    private fun refreshDonations() {
        repository.listenToListedDonations { donations ->
            adapter.submitList(donations)
            binding.emptyState.visibility = if (donations.isEmpty()) View.VISIBLE else View.GONE
        }
    }
}
