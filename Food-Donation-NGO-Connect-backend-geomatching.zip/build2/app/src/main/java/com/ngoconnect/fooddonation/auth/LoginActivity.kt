package com.ngoconnect.fooddonation.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.ngoconnect.fooddonation.R
import com.ngoconnect.fooddonation.data.FirebaseRepository
import com.ngoconnect.fooddonation.databinding.ActivityLoginBinding
import com.ngoconnect.fooddonation.donor.DonorHomeActivity
import com.ngoconnect.fooddonation.model.Ngo
import com.ngoconnect.fooddonation.model.Role
import com.ngoconnect.fooddonation.model.User
import com.ngoconnect.fooddonation.ngo.NgoDashboardActivity

/**
 * Screen 1: Login / Sign Up.
 *
 * Auth is real Firebase Authentication (email/password) -- every account
 * here lives in your Firebase project, there's no local/offline fallback.
 * After sign-in we look the user up in Firestore (`users/{uid}`):
 *   - no doc yet (brand new sign-up)   -> RoleSelectionActivity
 *   - doc exists with a role           -> DonorHomeActivity / NgoDashboardActivity
 *
 * "Demo Donor" / "Demo NGO" let anyone try the app without signing up by
 * hand: fixed email+password that self-provisions (with a seeded, already
 * verified NGO location) the first time it's tapped in your Firebase
 * project, so Geo Matching has something real to match against immediately.
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val auth = FirebaseAuth.getInstance()
    private val repository = FirebaseRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.loginButton.setOnClickListener { submitLogin() }
        binding.signUpPrompt.setOnClickListener {
            startActivity(Intent(this, RoleSelectionActivity::class.java))
        }
        binding.demoDonorButton.setOnClickListener { demoLogin(isNgo = false) }
        binding.demoNgoButton.setOnClickListener { demoLogin(isNgo = true) }
    }

    override fun onStart() {
        super.onStart()
        auth.currentUser?.let { routeSignedInUser(it.uid) }
    }

    private fun submitLogin() {
        val email = binding.emailInput.text?.toString()?.trim().orEmpty()
        val password = binding.passwordInput.text?.toString().orEmpty()
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show()
            return
        }
        setLoading(true)
        auth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener { result -> routeSignedInUser(result.user!!.uid) }
            .addOnFailureListener { onAuthFailure(it) }
    }

    private fun demoLogin(isNgo: Boolean) {
        val email = if (isNgo) DEMO_NGO_EMAIL else DEMO_DONOR_EMAIL
        setLoading(true)
        auth.signInWithEmailAndPassword(email, DEMO_PASSWORD)
            .addOnSuccessListener { result -> routeSignedInUser(result.user!!.uid) }
            .addOnFailureListener { error ->
                if (error is FirebaseAuthInvalidUserException) {
                    provisionDemoAccount(isNgo)
                } else {
                    setLoading(false)
                    Toast.makeText(this, error.message ?: "Demo login failed", Toast.LENGTH_SHORT).show()
                }
            }
    }

    /** First time a demo button is tapped in this Firebase project: create the account + seed data. */
    private fun provisionDemoAccount(isNgo: Boolean) {
        val email = if (isNgo) DEMO_NGO_EMAIL else DEMO_DONOR_EMAIL
        auth.createUserWithEmailAndPassword(email, DEMO_PASSWORD)
            .addOnSuccessListener { result ->
                val uid = result.user!!.uid
                if (isNgo) {
                    val ngo = Ngo(ngoId = uid, name = "Hope Foundation", verified = true, latitude = HYDERABAD_LAT, longitude = HYDERABAD_LNG)
                    repository.saveNgo(ngo) {
                        repository.saveUser(User(userId = uid, name = "Hope Foundation", role = Role.NGO, latitude = HYDERABAD_LAT, longitude = HYDERABAD_LNG)) {
                            setLoading(false)
                            goToNgoDashboard()
                        }
                    }
                } else {
                    repository.saveUser(User(userId = uid, name = "Green Leaf Restaurant", role = Role.DONOR, latitude = HYDERABAD_LAT, longitude = HYDERABAD_LNG)) {
                        setLoading(false)
                        goToDonorHome()
                    }
                }
            }
            .addOnFailureListener { onAuthFailure(it) }
    }

    private fun routeSignedInUser(uid: String) {
        repository.getUser(uid) { user ->
            setLoading(false)
            when {
                user == null -> {
                    startActivity(Intent(this, RoleSelectionActivity::class.java))
                    finish()
                }
                user.role == Role.NGO -> goToNgoDashboard()
                else -> goToDonorHome()
            }
        }
    }

    private fun goToDonorHome() {
        startActivity(Intent(this, DonorHomeActivity::class.java))
        finish()
    }

    private fun goToNgoDashboard() {
        startActivity(Intent(this, NgoDashboardActivity::class.java))
        finish()
    }

    private fun onAuthFailure(e: Exception) {
        setLoading(false)
        Toast.makeText(this, e.message ?: getString(R.string.error_generic), Toast.LENGTH_LONG).show()
    }

    private fun setLoading(loading: Boolean) {
        binding.loginButton.isEnabled = !loading
        binding.demoDonorButton.isEnabled = !loading
        binding.demoNgoButton.isEnabled = !loading
        binding.loginButton.text = if (loading) "Signing in…" else getString(R.string.login)
    }

    companion object {
        const val DEMO_DONOR_EMAIL = "donor.demo@gmail.com"
        const val DEMO_NGO_EMAIL = "ngo.demo@gmail.com"
        const val DEMO_PASSWORD = "Demo@1234"

        // Hyderabad city center -- keeps the demo donor/NGO close enough for
        // Geo Matching to produce a realistic "X km away".
        private const val HYDERABAD_LAT = 17.3850
        private const val HYDERABAD_LNG = 78.4867
    }
}
