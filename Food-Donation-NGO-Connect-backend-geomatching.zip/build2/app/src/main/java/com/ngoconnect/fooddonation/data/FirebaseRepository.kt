package com.ngoconnect.fooddonation.data

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.ngoconnect.fooddonation.model.Donation
import com.ngoconnect.fooddonation.model.DonationStatus
import com.ngoconnect.fooddonation.model.Ngo
import com.ngoconnect.fooddonation.model.User

/**
 * Data Management Module (Module 6).
 *
 * Single source of truth for reading/writing Cloud Firestore. Every other
 * module (Geo Matching, Donation Status, Impact Dashboard) goes through
 * this class instead of touching FirebaseFirestore directly.
 *
 * Collections:
 *   users/{userId}         -> User      (see model/User.kt)
 *   ngos/{ngoId}           -> Ngo       (see model/Ngo.kt)
 *   donations/{donationId} -> Donation  (see model/donation.kt)
 *
 * Matching security rules are in firestore.rules at the project root.
 * There is no offline/demo fallback here on purpose -- every write and
 * read goes to your actual Firebase project, so what you see in the app
 * is exactly what's in the Firebase console.
 *
 * Two queries below need a Firestore composite index the first time they
 * run (donorId+createdAt, ngoId+status). Logcat prints a direct console
 * link to create it the first time that happens -- just tap it once.
 */
class FirebaseRepository {

    private val db = FirebaseFirestore.getInstance()
    private val usersRef = db.collection(COLLECTION_USERS)
    private val ngosRef = db.collection(COLLECTION_NGOS)
    private val donationsRef = db.collection(COLLECTION_DONATIONS)

    // ---------- Users ----------

    fun saveUser(user: User, onComplete: (Boolean) -> Unit) {
        usersRef.document(user.userId).set(user)
            .addOnSuccessListener { onComplete(true) }
            .addOnFailureListener { onComplete(false) }
    }

    fun getUser(userId: String, onResult: (User?) -> Unit) {
        usersRef.document(userId).get()
            .addOnSuccessListener { doc -> onResult(doc.toObject(User::class.java)) }
            .addOnFailureListener { onResult(null) }
    }

    // ---------- NGOs ----------

    fun saveNgo(ngo: Ngo, onComplete: (Boolean) -> Unit) {
        ngosRef.document(ngo.ngoId).set(ngo)
            .addOnSuccessListener { onComplete(true) }
            .addOnFailureListener { onComplete(false) }
    }

    /** One-shot fetch of every NGO whose `verified` flag is true. Feeds the Geo Matching module. */
    fun getVerifiedNgos(onResult: (List<Ngo>) -> Unit) {
        ngosRef.whereEqualTo("verified", true).get()
            .addOnSuccessListener { snapshot ->
                onResult(snapshot.documents.mapNotNull { it.toObject(Ngo::class.java) })
            }
            .addOnFailureListener { onResult(emptyList()) }
    }

    // ---------- Donations ----------

    /** Creates a new donation doc (auto-generates donationId if blank) and returns its id. */
    fun createDonation(donation: Donation, onComplete: (String?) -> Unit) {
        val docRef = if (donation.donationId.isBlank()) donationsRef.document() else donationsRef.document(donation.donationId)
        val withId = donation.copy(donationId = docRef.id)
        docRef.set(withId)
            .addOnSuccessListener { onComplete(docRef.id) }
            .addOnFailureListener { onComplete(null) }
    }

    fun getDonation(donationId: String, onResult: (Donation?) -> Unit) {
        donationsRef.document(donationId).get()
            .addOnSuccessListener { onResult(it.toObject(Donation::class.java)) }
            .addOnFailureListener { onResult(null) }
    }

    /** Called by the Geo Matching module once it has found the nearest verified NGO. */
    fun updateDonationMatch(donationId: String, ngo: Ngo, distanceKm: Double, onComplete: (Boolean) -> Unit) {
        donationsRef.document(donationId)
            .update(
                mapOf(
                    "ngoId" to ngo.ngoId,
                    "ngoName" to ngo.name,
                    "distanceKm" to distanceKm,
                    "status" to DonationStatus.NGO_FOUND.name,
                ),
            )
            .addOnSuccessListener { onComplete(true) }
            .addOnFailureListener { onComplete(false) }
    }

    fun updateDonationStatus(donationId: String, status: DonationStatus, onComplete: (Boolean) -> Unit) {
        donationsRef.document(donationId).update("status", status.name)
            .addOnSuccessListener { onComplete(true) }
            .addOnFailureListener { onComplete(false) }
    }

    /** One-shot fetch of every donation for a given donor, most recent first. */
    fun donationsForDonor(donorId: String, onResult: (List<Donation>) -> Unit) {
        donationsRef.whereEqualTo("donorId", donorId)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .get()
            .addOnSuccessListener { snapshot -> onResult(snapshot.documents.mapNotNull { it.toObject(Donation::class.java) }) }
            .addOnFailureListener { onResult(emptyList()) }
    }

    /**
     * Real-time feed of one donor's donations. Call `.remove()` on the returned
     * registration (e.g. in onStop) to stop listening and avoid leaks.
     */
    fun listenToDonorDonations(donorId: String, onChange: (List<Donation>) -> Unit): ListenerRegistration {
        return donationsRef.whereEqualTo("donorId", donorId)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) {
                    onChange(emptyList())
                } else {
                    onChange(snapshot.documents.mapNotNull { it.toObject(Donation::class.java) })
                }
            }
    }

    /** Real-time feed of every donation still waiting for a Geo Match (used for diagnostics / admin views). */
    fun listenToListedDonations(onChange: (List<Donation>) -> Unit): ListenerRegistration {
        return donationsRef.whereEqualTo("status", DonationStatus.LISTED.name)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) {
                    onChange(emptyList())
                } else {
                    onChange(snapshot.documents.mapNotNull { it.toObject(Donation::class.java) })
                }
            }
    }

    /**
     * Real-time feed for the NGO Dashboard: every donation the Geo Matching
     * module has assigned to this specific NGO (ngoId == this NGO's uid) and
     * that's still waiting on them to accept it (status NGO_FOUND).
     */
    fun listenToNgoMatchedDonations(ngoId: String, onChange: (List<Donation>) -> Unit): ListenerRegistration {
        return donationsRef.whereEqualTo("ngoId", ngoId)
            .whereEqualTo("status", DonationStatus.NGO_FOUND.name)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) {
                    onChange(emptyList())
                } else {
                    onChange(snapshot.documents.mapNotNull { it.toObject(Donation::class.java) })
                }
            }
    }

    companion object {
        const val COLLECTION_USERS = "users"
        const val COLLECTION_NGOS = "ngos"
        const val COLLECTION_DONATIONS = "donations"
    }
}
