package com.ngoconnect.fooddonation.donor

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.ngoconnect.fooddonation.data.FirebaseRepository
import com.ngoconnect.fooddonation.databinding.ActivityCreateDonationBinding
import com.ngoconnect.fooddonation.geo.GeoMatchingRepository
import com.ngoconnect.fooddonation.geo.LocationHelper
import com.ngoconnect.fooddonation.model.Donation
import com.ngoconnect.fooddonation.model.DonationStatus
import java.util.Calendar
import java.util.Locale

/**
 * Screen: Create Donation (Donor Listing Module).
 *
 * On submit: writes the Donation to Firestore as LISTED, then immediately
 * hands off to the Geo Matching module to find the nearest verified NGO
 * using the donor's current device location, and assigns it.
 */
class CreateDonationActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreateDonationBinding
    private val repository = FirebaseRepository()
    private val geoMatchingRepository = GeoMatchingRepository(repository)
    private val calendar = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateDonationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupPickers()

        binding.submitDonationButton.setOnClickListener {
            submitDonation()
        }
    }

    private fun setupPickers() {
        binding.pickupDateInput.setOnClickListener {
            DatePickerDialog(
                this,
                { _, year, month, day ->
                    val dateStr = String.format(Locale.getDefault(), "%02d/%02d/%d", day, month + 1, year)
                    binding.pickupDateInput.setText(dateStr)
                },
                calendar[Calendar.YEAR],
                calendar[Calendar.MONTH],
                calendar[Calendar.DAY_OF_MONTH],
            ).show()
        }

        binding.pickupTimeInput.setOnClickListener {
            TimePickerDialog(
                this,
                { _, hour, minute ->
                    val timeStr = String.format(Locale.getDefault(), "%02d:%02d", hour, minute)
                    binding.pickupTimeInput.setText(timeStr)
                },
                calendar[Calendar.HOUR_OF_DAY],
                calendar[Calendar.MINUTE],
                true,
            ).show()
        }
    }

    private fun submitDonation() {
        val foodType = binding.foodTypeInput.text.toString().trim()
        val quantity = binding.quantityInput.text.toString().trim()
        val date = binding.pickupDateInput.text.toString().trim()
        val time = binding.pickupTimeInput.text.toString().trim()
        val location = binding.pickupLocationInput.text.toString().trim()

        if (foodType.isEmpty() || quantity.isEmpty() || date.isEmpty() || time.isEmpty() || location.isEmpty()) {
            Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show()
            return
        }

        val donorId = FirebaseAuth.getInstance().currentUser?.uid
        if (donorId == null) {
            Toast.makeText(this, "You're not signed in. Please log in again.", Toast.LENGTH_SHORT).show()
            return
        }

        val donation = Donation(
            donorId = donorId,
            foodType = foodType,
            quantity = quantity,
            pickupDate = date,
            pickupTime = time,
            pickupLocation = location,
            description = binding.descriptionInput.text.toString().trim(),
            status = DonationStatus.LISTED,
            createdAt = System.currentTimeMillis(),
        )

        setLoading(true)
        repository.createDonation(donation) { donationId ->
            if (donationId == null) {
                setLoading(false)
                Toast.makeText(this, "Couldn't save the donation. Try again.", Toast.LENGTH_SHORT).show()
                return@createDonation
            }
            runGeoMatching(donationId, donation)
        }
    }

    /** Geo Matching Module hand-off: locate the donor, then match + assign the nearest verified NGO. */
    private fun runGeoMatching(donationId: String, donation: Donation) {
        LocationHelper.getCurrentLocation(
            context = this,
            onResult = { lat, lng ->
                geoMatchingRepository.matchDonationToNearestNgo(donationId, lat, lng) { match ->
                    setLoading(false)
                    if (match != null) {
                        showSuccessSummary(donation, "Matched with ${match.ngo.name} · ${"%.1f".format(match.distanceKm)} km away")
                    } else {
                        showSuccessSummary(donation, "No verified NGO is nearby yet — we'll match one as soon as there is.")
                    }
                }
            },
            onFailure = {
                setLoading(false)
                showSuccessSummary(donation, "Enable location permission so we can match the nearest NGO.")
            },
        )
    }

    private fun showSuccessSummary(donation: Donation, matchLine: String) {
        val message = """
            Your donation has been listed!

            Food: ${donation.foodType}
            Quantity: ${donation.quantity}
            Pickup: ${donation.pickupDate} at ${donation.pickupTime}
            Location: ${donation.pickupLocation}

            $matchLine
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("Donation Submitted")
            .setMessage(message)
            .setPositiveButton("OK") { _, _ ->
                finish()
            }
            .setCancelable(false)
            .show()
    }

    private fun setLoading(loading: Boolean) {
        binding.submitDonationButton.isEnabled = !loading
        binding.submitDonationButton.text = if (loading) "Finding nearest NGO…" else getString(com.ngoconnect.fooddonation.R.string.submit_donation)
    }
}
