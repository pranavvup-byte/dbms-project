package com.ngoconnect.fooddonation.geo

import com.ngoconnect.fooddonation.data.FirebaseRepository
import com.ngoconnect.fooddonation.model.Ngo
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Geo Matching Module (Module 3).
 *
 * Given a donation's pickup coordinates, finds the closest verified NGO
 * (pulled from Firestore via FirebaseRepository) and writes the match back
 * onto the donation, moving its status LISTED -> NGO_FOUND.
 *
 * This is a straightforward nearest-neighbour scan over verified NGOs using
 * the Haversine formula. It's fine for the NGO counts a project like this
 * will realistically have; if the NGO list ever grows large, swap
 * getVerifiedNgos() for a Firestore geohash query (e.g. GeoFire) without
 * changing this class's public API.
 */
@Suppress("unused")
class GeoMatchingRepository(
    private val firebaseRepository: FirebaseRepository = FirebaseRepository()
) {

    data class Match(val ngo: Ngo, val distanceKm: Double)

    /** Great-circle distance between two lat/lng points, in kilometres. */
    fun distanceKm(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
        val earthRadiusKm = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLng = Math.toRadians(lng2 - lng1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
            sin(dLng / 2) * sin(dLng / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return earthRadiusKm * c
    }

    /** Finds the nearest verified NGO to (donorLat, donorLng). Null if no verified NGOs exist yet. */
    fun findNearestNgo(donorLat: Double, donorLng: Double, onResult: (Match?) -> Unit) {
        firebaseRepository.getVerifiedNgos { ngos ->
            val nearest = ngos.minByOrNull { distanceKm(donorLat, donorLng, it.latitude, it.longitude) }
            if (nearest == null) {
                onResult(null)
            } else {
                onResult(Match(nearest, distanceKm(donorLat, donorLng, nearest.latitude, nearest.longitude)))
            }
        }
    }

    /**
     * Full Module 3 flow: locate the nearest verified NGO for a donation and
     * persist the match in Firestore (status -> NGO_FOUND). onComplete gets
     * null if there were no verified NGOs or the write failed.
     */
    fun matchDonationToNearestNgo(
        donationId: String,
        donorLat: Double,
        donorLng: Double,
        onComplete: (Match?) -> Unit
    ) {
        findNearestNgo(donorLat, donorLng) { match ->
            if (match == null) {
                onComplete(null)
            } else {
                firebaseRepository.updateDonationMatch(donationId, match.ngo, match.distanceKm) { success ->
                    onComplete(if (success) match else null)
                }
            }
        }
    }
}
