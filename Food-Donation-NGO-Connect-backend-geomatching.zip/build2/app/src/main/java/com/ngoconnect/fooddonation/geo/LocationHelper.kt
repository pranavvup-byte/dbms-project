package com.ngoconnect.fooddonation.geo

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource

/**
 * Geo Matching Module (Module 3) — location detection.
 *
 * Wraps FusedLocationProviderClient behind one callback-based call so
 * activities/fragments don't need to touch Play Services APIs directly.
 * ACCESS_FINE_LOCATION / ACCESS_COARSE_LOCATION are already declared in
 * AndroidManifest.xml — this class assumes the runtime permission prompt
 * has already been shown (use PERMISSIONS below with
 * ActivityCompat.requestPermissions).
 */
@Suppress("unused")
object LocationHelper {

    val PERMISSIONS = arrayOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
    )

    fun hasLocationPermission(context: Context): Boolean {
        return PERMISSIONS.any {
            ActivityCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    /**
     * Resolves the device's current lat/lng. Calls onFailure if permission is
     * missing or a location fix can't be obtained — callers should fall back
     * to a manually entered pickup address in that case (e.g. geocode the
     * address text) rather than blocking the flow.
     */
    @SuppressLint("MissingPermission")
    fun getCurrentLocation(
        context: Context,
        onResult: (lat: Double, lng: Double) -> Unit,
        onFailure: () -> Unit
    ) {
        if (!hasLocationPermission(context)) {
            onFailure()
            return
        }
        val client = LocationServices.getFusedLocationProviderClient(context)
        val cancellationSource = CancellationTokenSource()
        client.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, cancellationSource.token)
            .addOnSuccessListener { location ->
                if (location != null) onResult(location.latitude, location.longitude) else onFailure()
            }
            .addOnFailureListener { onFailure() }
    }
}
