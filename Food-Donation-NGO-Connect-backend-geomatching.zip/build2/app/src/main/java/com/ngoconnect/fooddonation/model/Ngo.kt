package com.ngoconnect.fooddonation.model

/**
 * Maps to the `ngos` collection in Firestore:
 * ngos/{ngoId} -> { name, verified, location }
 */
data class Ngo(
    val ngoId: String = "",
    val name: String = "",
    val verified: Boolean = false,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0
)