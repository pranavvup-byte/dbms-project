package com.ngoconnect.fooddonation.model

/**
 * Maps to the `users` collection in Firestore:
 * users/{userId} -> { name, role, location }
 */
data class User(
    val userId: String = "",
    val name: String = "",
    val role: Role = Role.DONOR,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0
)

enum class Role {
    DONOR, NGO, BOTH
}