package com.ngoconnect.fooddonation.model

/**
 * Maps to the `donations` collection in Firestore:
 * donations/{donationId} -> { donorId, foodType, quantity, pickupTime, location, status }
 */
data class Donation(
    val donationId: String = "",
    val donorId: String = "",
    val foodType: String = "",
    val quantity: String = "",
    val pickupDate: String = "",
    val pickupTime: String = "",
    val pickupLocation: String = "",
    val description: String = "",
    val distanceKm: Double = 0.0,
    val status: DonationStatus = DonationStatus.LISTED,
    val ngoId: String? = null,
    val ngoName: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

/** Donor lists food -> System finds verified NGO -> NGO accepts -> Pickup scheduled -> Completed */
enum class DonationStatus(val label: String) {
    LISTED("Listed"),
    NGO_FOUND("NGO Found"),
    PICKUP_SCHEDULED("Pickup Scheduled"),
    COMPLETED("Completed")
}