package com.ngoconnect.fooddonation.ngo

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.ListenerRegistration
import com.ngoconnect.fooddonation.auth.LoginActivity
import com.ngoconnect.fooddonation.data.FirebaseRepository
import com.ngoconnect.fooddonation.databinding.ActivityNgoDashboardBinding
import com.ngoconnect.fooddonation.donor.DonationAdapter
import com.ngoconnect.fooddonation.donor.DonorHomeActivity
import com.ngoconnect.fooddonation.model.Role
import com.ngoconnect.fooddonation.status.DonationStatusActivity

/**
 * NGO's home screen: every donation the Geo Matching module has assigned
 * to THIS NGO specifically (not every open donation on the platform) and
 * that's waiting to be accepted. Tapping one opens Donation Status, where
 * accepting moves it into Pickup Scheduled.
 */
class NgoDashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNgoDashboardBinding
    private val repository = FirebaseRepository()
    private lateinit var adapter: DonationAdapter
    private var donationsListener: ListenerRegistration? = null

    private val ngoId: String
        get() = FirebaseAuth.getInstance().currentUser?.uid.orEmpty()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNgoDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository.getUser(ngoId) { user ->
            binding.ngoName.text = user?.name ?: "NGO"
            if (user?.role == Role.BOTH) {
                binding.switchRoleButton.visibility = View.VISIBLE
                binding.switchRoleButton.setOnClickListener {
                    startActivity(Intent(this, DonorHomeActivity::class.java))
                    finish()
                }
            }
        }

        adapter = DonationAdapter(emptyList()) { donation ->
            startActivity(
                Intent(this, DonationStatusActivity::class.java)
                    .putExtra(DonationStatusActivity.EXTRA_DONATION_ID, donation.donationId),
            )
        }

        binding.nearbyDonationsRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.nearbyDonationsRecyclerView.adapter = adapter

        binding.logoutButton.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    override fun onStart() {
        super.onStart()
        donationsListener = repository.listenToNgoMatchedDonations(ngoId) { donations ->
            adapter.submitList(donations)
            binding.emptyState.visibility = if (donations.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    override fun onStop() {
        super.onStop()
        donationsListener?.remove()
        donationsListener = null
    }
}
