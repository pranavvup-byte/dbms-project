package com.ngoconnect.fooddonation.status

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.ngoconnect.fooddonation.R
import com.ngoconnect.fooddonation.data.FirebaseRepository
import com.ngoconnect.fooddonation.databinding.ActivityDonationStatusBinding
import com.ngoconnect.fooddonation.donor.DonationAdapter
import com.ngoconnect.fooddonation.model.Donation
import com.ngoconnect.fooddonation.model.DonationStatus
import com.ngoconnect.fooddonation.model.Role

class DonationStatusActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDonationStatusBinding
    private val repository = FirebaseRepository()
    private var currentDonation: Donation? = null
    private var userRole: Role? = null

    companion object {
        const val EXTRA_DONATION_ID = "extra_donation_id"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDonationStatusBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val donationId = intent.getStringExtra(EXTRA_DONATION_ID) ?: ""
        val userId = FirebaseAuth.getInstance().currentUser?.uid.orEmpty()

        repository.getUser(userId) { user ->
            userRole = user?.role ?: Role.DONOR
            loadDonation(donationId)
        }

        binding.actionButton.setOnClickListener {
            handleAction()
        }
    }

    private fun loadDonation(donationId: String) {
        repository.getDonation(donationId) { donation ->
            if (donation != null) {
                currentDonation = donation
                binding.statusFoodType.text = donation.foodType
                binding.statusQuantity.text = donation.quantity
                binding.currentStatusLabel.text = donation.status.label.uppercase()
                binding.currentStatusLabel.setBackgroundResource(
                    DonationAdapter.statusPillBackground(donation.status),
                )
                binding.currentStatusLabel.setTextColor(
                    DonationAdapter.statusPillTextColor(this, donation.status),
                )
                
                updateTimeline(donation.status)
                updateActionButton(donation.status)
            }
        }
    }

    private fun updateTimeline(status: DonationStatus) {
        val activeColor = getColor(R.color.primary)
        val inactiveColor = getColor(R.color.text_secondary)

        binding.stepListed.setTextColor(activeColor)
        binding.stepMatched.setTextColor(if (status >= DonationStatus.NGO_FOUND) activeColor else inactiveColor)
        binding.stepScheduled.setTextColor(if (status >= DonationStatus.PICKUP_SCHEDULED) activeColor else inactiveColor)
        binding.stepCompleted.setTextColor(if (status >= DonationStatus.COMPLETED) activeColor else inactiveColor)
        
        binding.stepListed.text = getString(R.string.step_listed_done)
        binding.stepMatched.text = if (status >= DonationStatus.NGO_FOUND) getString(R.string.step_matched_done) else getString(R.string.step_matched_todo)
        binding.stepScheduled.text = if (status >= DonationStatus.PICKUP_SCHEDULED) getString(R.string.step_scheduled_done) else getString(R.string.step_scheduled_todo)
        binding.stepCompleted.text = if (status >= DonationStatus.COMPLETED) getString(R.string.step_completed_done) else getString(R.string.step_completed_todo)
    }

    private fun updateActionButton(status: DonationStatus) {
        binding.actionButton.visibility = View.VISIBLE
        when {
            (userRole == Role.NGO || userRole == Role.BOTH) && (status == DonationStatus.NGO_FOUND) -> {
                // The Geo Matching module already assigned this NGO automatically;
                // accepting here confirms the pickup time the donor proposed.
                binding.actionButton.text = getString(R.string.action_accept_donation)
            }
            status == DonationStatus.PICKUP_SCHEDULED -> {
                binding.actionButton.text = getString(R.string.action_mark_completed)
            }
            else -> {
                binding.actionButton.visibility = View.GONE
            }
        }
    }

    private fun handleAction() {
        val donation = currentDonation ?: return
        val nextStatus = when (donation.status) {
            DonationStatus.LISTED -> DonationStatus.NGO_FOUND
            DonationStatus.NGO_FOUND -> DonationStatus.PICKUP_SCHEDULED
            DonationStatus.PICKUP_SCHEDULED -> DonationStatus.COMPLETED
            else -> null
        } ?: return

        repository.updateDonationStatus(donation.donationId, nextStatus) { success ->
            if (success) {
                Toast.makeText(this, "Status updated to ${nextStatus.label}", Toast.LENGTH_SHORT).show()
                loadDonation(donation.donationId)
            } else {
                Toast.makeText(this, getString(R.string.error_generic), Toast.LENGTH_SHORT).show()
            }
        }
    }
}